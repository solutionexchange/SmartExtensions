ace.define("ace/snippets/gherkin",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="gherkin"});                (function() {
                    ace.require(["ace/snippets/gherkin"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            