ace.define("ace/snippets/jack",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="jack"});                (function() {
                    ace.require(["ace/snippets/jack"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            